#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
List rgm_cpp(const arma::mat& Xb,
             const arma::uvec& sp_r,
             int iter = 500,
             double gamma = -0.5,
             double mul = 0.1) {

  arma::uvec sp = sp_r - 1;   // R index -> C++ index
  arma::mat Xp = Xb.rows(sp);

  int m = Xp.n_rows;
  int p = Xp.n_cols;

  arma::rowvec fbar = mean(Xb, 0);
  arma::mat S = cov(Xb);
  arma::vec diagS = S.diag();

  arma::rowvec min_a = min(Xp, 0);
  arma::rowvec max_b = max(Xp, 0);
  arma::rowvec R = max_b - min_a;

  double tau;
  if (m >= 100) tau = 0.05;
  else if (m >= 30) tau = -0.15 / 70.0 * (m - 30) + 0.2;
  else if (m >= 10) tau = -0.8 / 20.0 * (m - 10) + 1.0;
  else tau = 1.0;

  tau *= mul;

  arma::rowvec A = sqrt(var(Xp, 0, 0) / m);

  double min_nonzero = datum::inf;
  for (int j = 0; j < p; j++) {
    if (A[j] != 0.0 && A[j] < min_nonzero) min_nonzero = A[j];
  }
  for (int j = 0; j < p; j++) {
    if (A[j] == 0.0) A[j] = min_nonzero;
  }

  arma::rowvec beta = m * tau * std::abs(gamma) * A;

  arma::vec alpha(p, fill::zeros);
  arma::vec Loss(iter, fill::zeros);

  arma::mat Xp_center = Xp;
  arma::mat Xp_min = Xp;
  arma::mat Xp_max = Xp;

  for (int j = 0; j < p; j++) {
    Xp_center.col(j) -= fbar[j];
    Xp_min.col(j)    -= min_a[j];
    Xp_max.col(j)     = max_b[j] - Xp.col(j);
  }

  int final_iter = iter;

  for (int it = 0; it < iter; it++) {

    arma::vec Salpha = S * alpha;

    double alphafbar = dot(alpha, fbar.t());
    double alphaSalpha = dot(alpha, Salpha);

    arma::vec eta_center = Xp_center * alpha;
    arma::vec eta_raw = Xp * alpha;

    double common_loss =
      -gamma * (gamma + 1.0) / 2.0 * alphaSalpha;

    arma::vec exp_center = exp(gamma * eta_center + common_loss);
    double L = sum(exp_center);

    arma::vec w = exp(gamma * eta_raw);

    arma::rowvec Ma = sum(Xp_min.each_col() % w, 0);
    arma::rowvec Mb = sum(Xp_max.each_col() % w, 0);

    arma::rowvec delta1 = -alpha.t();

    arma::rowvec aj =
      min_a * gamma -
      fbar * gamma -
      gamma * (1.0 + gamma) * Salpha.t();

    arma::rowvec bj =
      max_b * gamma -
      fbar * gamma -
      gamma * (1.0 + gamma) * Salpha.t();

    double ggg =
      -gamma * alphafbar -
      gamma * (gamma + 1.0) / 2.0 * alphaSalpha;

    double eggg = std::exp(ggg);

    arma::rowvec Rfirst =
      Ma * eggg % bj + Mb * eggg % aj;

    arma::rowvec Rsecond =
      Ma * eggg % square(bj) -
      Ma * eggg * gamma * (gamma + 1.0) % diagS.t() +
      Mb * eggg % square(aj) -
      Mb * eggg * gamma * (gamma + 1.0) % diagS.t();

    arma::rowvec Rfirst2(p, fill::zeros);

    for (int j = 0; j < p; j++) {
      if (alpha[j] != 0.0) {
        Rfirst2[j] = Rfirst[j] + R[j] * beta[j] * ((alpha[j] > 0) ? 1.0 : -1.0);
      } else if (std::abs(Rfirst[j]) > R[j] * beta[j]) {
        Rfirst2[j] = Rfirst[j] - R[j] * beta[j] * ((Rfirst[j] > 0) ? 1.0 : -1.0);
      }
    }

    arma::rowvec delta2 = -Rfirst2 / Rsecond;

    double best_val = datum::inf;
    int best_j = 0;
    int best_type = 1;

    for (int type = 1; type <= 2; type++) {
      arma::rowvec delta = (type == 1) ? delta1 : delta2;

      for (int j = 0; j < p; j++) {

        double d = delta[j];

        double Cg =
          std::exp(
            -gamma * alphafbar -
            gamma * (gamma + 1.0) / 2.0 * alphaSalpha -
            gamma * fbar[j] * d -
            gamma * (gamma + 1.0) * Salpha[j] * d -
            gamma * (gamma + 1.0) / 2.0 * diagS[j] * d * d
          );

        double val =
          Cg * std::exp(gamma * max_b[j] * d) / R[j] * Ma[j] +
          Cg * std::exp(gamma * min_a[j] * d) / R[j] * Mb[j] -
          L +
          beta[j] * (std::abs(alpha[j] + d) - std::abs(alpha[j]));

        if (std::isfinite(val) && val < best_val) {
          best_val = val;
          best_j = j;
          best_type = type;
        }
      }
    }

    double delta = (best_type == 1) ? delta1[best_j] : delta2[best_j];

    alpha[best_j] += delta;

    Salpha = S * alpha;
    alphaSalpha = dot(alpha, Salpha);

    arma::vec eta_new = Xp_center * alpha;

    Loss[it] =
      sum(exp(gamma * eta_new -
              gamma * (gamma + 1.0) / 2.0 * alphaSalpha));

    final_iter = it + 1;

    if (it > 0) {
      double relative =
        (Loss[it - 1] - Loss[it]) / (1.0 + std::abs(Loss[it]));

      if (relative < 1e-10 || Loss[it] >= Loss[it - 1]) {
        break;
      }
    }
  }

  return List::create(
    Named("alpha") = alpha,
    Named("iter") = final_iter
  );
}